import subprocess
import sys
import os
import shutil

def build():
    print("==================================================")
    print("  Building GitHub Easy Push Standalone (.exe)  ")
    print("==================================================")

    # Ensure PyInstaller is installed
    try:
        import PyInstaller
    except ImportError:
        print("[*] PyInstaller not found. Installing pyinstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])

    icon_path = os.path.abspath("icon.png")

    cmd = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--onedir",
        "--windowed",
        "--name=GitHub_Easy_Push",
        f"--icon={icon_path}",
        f"--add-data={icon_path};.",
        "main.py"
    ]

    print(f"[*] Running command: {' '.join(cmd)}")
    res = subprocess.call(cmd)
    if res == 0:
        dist_exe = os.path.abspath(os.path.join("dist", "GitHub_Easy_Push", "GitHub_Easy_Push.exe"))
        root_exe = os.path.abspath("GitHub_Easy_Push.exe")
        shutil.copy(dist_exe, root_exe)

        print("==================================================")
        print(" BUILD SUCCESSFUL!")
        print(f" Executable generated & placed at: {root_exe}")
        print("==================================================")
    else:
        print("==================================================")
        print(" BUILD FAILED. Check PyInstaller logs above.")
        print("==================================================")

if __name__ == "__main__":
    build()
